import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { rtdb } from "../database/firebase";
import { ref, onValue } from "firebase/database";
import { GlobalStyle as GS } from "../styles/GlobalStyle";

export default function EmployeeList({ navigation }) {
  const [employees, setEmployees] = useState(null);

  useEffect(() => {
    const empRef = ref(rtdb, "Employees");
    const unsubscribe = onValue(empRef, (snap) => {
      const data = snap.val();
      setEmployees(data || {});
    });
    return () => unsubscribe();
  }, []);

  if (employees === null) {
    return (
      <SafeAreaView style={GS.container}>
        <View style={GS.center}>
          <ActivityIndicator />
          <Text>Indlæser medarbejdere…</Text>
        </View>
      </SafeAreaView>
    );
  }

  const ids = Object.keys(employees);
  const liste = Object.values(employees);

  if (ids.length === 0) {
    return (
      <SafeAreaView style={GS.container}>
        <View style={GS.center}>
          <Text>Ingen medarbejdere endnu</Text>
        </View>
      </SafeAreaView>
    );
  }

  const vælgMedarbejder = (id) => {
    const emp = employees[id];
    navigation.navigate("Employee Details", { employee: [id, emp] });
  };

  return (
    <SafeAreaView style={GS.container}>
      <Text style={GS.pageTitle}>Registrerede medarbejdere</Text>
      <FlatList
        data={liste}
        keyExtractor={(_, i) => ids[i]}
        contentContainerStyle={GS.listContainer}
        renderItem={({ item, index }) => (
          <TouchableOpacity
            style={GS.card}
            onPress={() => vælgMedarbejder(ids[index])}
          >
            <Text style={GS.cardTitle}>{item.name || "Uden navn"}</Text>
            <Text style={GS.cardSubtitle}>{item.role || "Ingen rolle"}</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}
