import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { rtdb } from "../database/firebase";
import { ref, onValue } from "firebase/database";
import { GlobalStyle as GS } from "../styles/GlobalStyle";

export default function ShiftList({ navigation }) {
  const [shifts, setShifts] = useState(null);

  useEffect(() => {
    const shiftRef = ref(rtdb, "Shifts");
    const unsubscribe = onValue(shiftRef, (snap) => {
      const data = snap.val();
      setShifts(data || {});
    });
    return () => unsubscribe();
  }, []);

  if (shifts === null) {
    return (
      <SafeAreaView style={GS.container}>
        <View style={GS.center}>
          <ActivityIndicator />
          <Text>Indlæser vagter…</Text>
        </View>
      </SafeAreaView>
    );
  }

  const ids = Object.keys(shifts);
  const liste = Object.values(shifts);

  if (ids.length === 0) {
    return (
      <SafeAreaView style={GS.container}>
        <View style={GS.center}>
          <Text>Ingen vagter oprettet endnu</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={GS.container}>
      <Text style={GS.pageTitle}>Vagtplan</Text>
      <FlatList
        data={liste}
        keyExtractor={(_, i) => ids[i]}
        contentContainerStyle={GS.listContainer}
        renderItem={({ item }) => (
          <TouchableOpacity style={GS.card}>
            <Text style={GS.cardTitle}>{item.role} </Text>
            <Text style={GS.cardSubtitle}>
              {item.date} kl. {item.time}
            </Text>
            <Text>{item.location}</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}
