import React, { useEffect, useState } from "react";
import { View, Text, Button, Alert, Platform, ScrollView, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { rtdb } from "../database/firebase";
import { ref, remove } from "firebase/database";

const labels = {
  name: "Navn",
  role: "Rolle",
  phone: "Telefon",
  email: "E-mail",
};

export default function EmployeeDetails({ navigation, route }) {
  const [emp, setEmp] = useState(null);
  const id = route?.params?.employee?.[0];
  const data = route?.params?.employee?.[1];

  useEffect(() => {
    setEmp(data ?? null);
    return () => setEmp(null);
  }, []);

  const rediger = () => navigation.navigate("Edit Employee", { employee: [id, emp] });

  const slet = async () => {
    try {
      await remove(ref(rtdb, `Employees/${id}`));
      navigation.goBack();
    } catch (e) {
      Alert.alert(e?.message || "Noget gik galt.");
    }
  };

  const bekræftSlet = () => {
    if (Platform.OS === "ios" || Platform.OS === "android") {
      Alert.alert("Er du sikker?", "Vil du slette medarbejderen?", [
        { text: "Annuller", style: "cancel" },
        { text: "Slet", style: "destructive", onPress: slet },
      ]);
    } else {
      const ok = window.confirm("Vil du slette medarbejderen?");
      if (ok) slet();
    }
  };

  if (!emp) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.center}>
          <Text style={styles.noDataText}>Ingen data</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.header}>Medarbejderdetaljer</Text>
        {Object.entries(emp).map(([nøgle, værdi]) => (
          <View style={styles.card} key={nøgle}>
            <Text style={styles.label}>{labels[nøgle] ?? nøgle}</Text>
            <Text style={styles.value}>{String(værdi)}</Text>
          </View>
        ))}

        <View style={{ height: 20 }} />

        <View style={styles.buttonContainer}>
          <Button title="Redigér" onPress={rediger} color="#007AFF" />
        </View>
        <View style={{ height: 12 }} />
        <View style={styles.buttonContainer}>
          <Button title="Slet" color="#d33" onPress={bekræftSlet} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f4f6f8",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  noDataText: {
    fontSize: 16,
    color: "#666",
  },
  scrollContent: {
    padding: 20,
    alignItems: "center",
  },
  header: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#007AFF",
  },
  card: {
    width: "100%",
    backgroundColor: "#fff",
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: "#555",
    marginBottom: 4,
  },
  value: {
    fontSize: 16,
    fontWeight: "500",
    color: "#222",
  },
  buttonContainer: {
    width: "100%",
    borderRadius: 8,
    overflow: "hidden",
  },
});
