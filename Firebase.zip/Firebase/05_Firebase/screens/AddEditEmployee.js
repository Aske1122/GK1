import React, { useEffect, useState, useMemo } from "react";
import { ScrollView, View, Text, TextInput, Button, Alert } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { rtdb } from "../database/firebase";
import { ref, push, update } from "firebase/database";
import { GlobalStyle as GS, Farver } from "../styles/GlobalStyle";

const initialState = { name: "", role: "", phone: "", email: "" };

const labels = {
  name: "Navn",
  role: "Rolle (fx bartender, tekniker)",
  phone: "Telefon",
  email: "E-mail",
};

export default function AddEditEmployee({ navigation, route }) {
  const [nyMedarbejder, setNyMedarbejder] = useState(initialState);

  const erRediger = useMemo(() => route?.name === "Edit Employee", [route?.name]);

  useEffect(() => {
    if (erRediger) {
      const empObjekt = route?.params?.employee?.[1];
      if (empObjekt) setNyMedarbejder({ ...initialState, ...empObjekt });
    }
    return () => setNyMedarbejder(initialState);
  }, [erRediger]);

  const ændrTekst = (nøgle, værdi) =>
    setNyMedarbejder((prev) => ({ ...prev, [nøgle]: værdi }));

  const gem = async () => {
    const { name, role, phone, email } = nyMedarbejder;

    if (!name?.trim() || !role?.trim() || !phone?.trim() || !email?.trim()) {
      return Alert.alert("Alle felter skal udfyldes.");
    }

    try {
      if (erRediger) {
        const id = route?.params?.employee?.[0];
        await update(ref(rtdb, `Employees/${id}`), nyMedarbejder);
        Alert.alert("Medarbejderen er opdateret.");
        navigation.navigate("Employee Details", { employee: [id, nyMedarbejder] });
      } else {
        await push(ref(rtdb, "/Employees/"), nyMedarbejder);
        Alert.alert("Medarbejderen er gemt.");
        setNyMedarbejder(initialState);
      }
    } catch (e) {
      Alert.alert(e?.message || "Noget gik galt.");
    }
  };

  return (
    <SafeAreaView style={GS.container}>
      <ScrollView contentContainerStyle={GS.formContainer}>
        <Text style={GS.pageTitle}>
          {erRediger ? "Redigér medarbejder" : "Ny medarbejder"}
        </Text>

        {Object.keys(initialState).map((nøgle) => (
          <View style={GS.inputGroup} key={nøgle}>
            <Text style={GS.label}>{labels[nøgle]}</Text>
            <TextInput
              value={String(nyMedarbejder[nøgle] ?? "")}
              onChangeText={(v) => ændrTekst(nøgle, v)}
              style={GS.input}
              placeholder={labels[nøgle]}
            />
          </View>
        ))}

        <Button
          title={erRediger ? "Gem ændringer" : "Tilføj medarbejder"}
          color={Farver.primary}
          onPress={gem}
        />
      </ScrollView>
    </SafeAreaView>
  );
}
