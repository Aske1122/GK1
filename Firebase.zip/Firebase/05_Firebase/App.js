import React from "react";
import { StyleSheet } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { firebaseApp, rtdb } from "./database/firebase";

// Importér screens
import EmployeeList from "./screens/EmployeeList";
import EmployeeDetails from "./screens/EmployeeDetails";
import AddEditEmployee from "./screens/AddEditEmployee";
import AdminShiftList from "./screens/AdminShiftList";

// Opret Stack og Tab udenfor App
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Stack til medarbejdere
const StackNavigation = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Employee List" component={EmployeeList} />
      <Stack.Screen name="Employee Details" component={EmployeeDetails} />
      <Stack.Screen name="Edit Employee" component={AddEditEmployee} />
    </Stack.Navigator>
  );
};

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={{
            headerShown: false, // Skjul header for Tab-skærme
            tabBarActiveTintColor: "#007AFF",
            tabBarInactiveTintColor: "gray",
          }}
        >
          <Tab.Screen
            name="Hjem"
            component={StackNavigation}
            options={{
              tabBarIcon: ({ color, size }) => (
                <Ionicons name="people" size={size} color={color} />
              ),
            }}
          />
          <Tab.Screen
            name="Add"
            component={AddEditEmployee}
            options={{
              tabBarIcon: ({ color, size }) => (
                <Ionicons name="add" size={size} color={color} />
              ),
            }}
          />
          <Tab.Screen
            name="Admin"
            component={AdminShiftList}
            options={{
              tabBarIcon: ({ color, size }) => (
                <Ionicons name="settings" size={size} color={color} />
              ),
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
