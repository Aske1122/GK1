import { StyleSheet } from "react-native";

export const Farver = {
  primary: "#2D9CDB",
  secondary: "#56CCF2",
  background: "#F8F9FA",
  text: "#333",
  lightGray: "#E0E0E0",
};

export const GlobalStyle = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Farver.background,
    padding: 16,
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  pageTitle: {
    fontSize: 22,
    fontWeight: "bold",
    marginVertical: 12,
    color: Farver.primary,
  },
  formContainer: {
    paddingBottom: 40,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    marginBottom: 4,
    color: Farver.text,
  },
  input: {
    borderWidth: 1,
    borderColor: Farver.lightGray,
    borderRadius: 8,
    padding: 10,
    backgroundColor: "white",
  },
  listContainer: {
    paddingBottom: 20,
  },
  card: {
    backgroundColor: "white",
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 14,
    color: "#555",
  },
});
