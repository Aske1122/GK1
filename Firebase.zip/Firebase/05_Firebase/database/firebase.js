// database/firebase.js
import { initializeApp, getApps, getApp } from "firebase/app";
import { getDatabase } from "firebase/database";

// Firebase configuration (fra Firebase Console → Project settings)
const firebaseConfig = {
  apiKey: "AIzaSyDk6mzoOMvdDyfgzfGREvnTh64nfDIbfWg",
  authDomain: "fir-cf941.firebaseapp.com",
  projectId: "fir-cf941",
  storageBucket: "fir-cf941.firebasestorage.app",
  messagingSenderId: "55034537138",
  appId: "1:55034537138:web:cda86107f951851dc615ab",
};

// Init Firebase kun én gang (undgår require cycles)
export const firebaseApp = getApps().length ? getApp() : initializeApp(firebaseConfig);

// Tilføj din Realtime Database URL (fra Firebase Console → Realtime Database → Data → copy URL)
export const rtdb = getDatabase(
  firebaseApp,
  "https://fir-cf941-default-rtdb.europe-west1.firebasedatabase.app"
);


